const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const ctx={Engine:require('./dist/engine'),window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('./dist/real.js','utf8'),ctx);
const E=ctx.Engine,d=E.demo();E.validate(d);const w=[40,30,15,15];
const a=E.route(d,d.defaultStart,d.defaultDest,w,1,true),b=E.route(d,d.defaultStart,d.defaultDest,w,1,false);
assert(a&&b&&a.exposure<b.exposure&&a.km>=b.km-1e-9);
const rank=E.rankShelters(d,d.defaultStart,w,1,20,false);assert(rank.some(r=>!r.reason));
console.log('PASS real data:',d.nodes.length,'nodes',d.edges.length,'edges',d.shelters.length,'shelters');
console.log('Default demo: least-risk',a.km.toFixed(2),'km vs shortest',b.km.toFixed(2),'km ->',(100*(1-a.exposure/b.exposure)).toFixed(1)+'% less exposure');
