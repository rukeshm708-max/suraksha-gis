# SURAKSHA: build real network from OSM roads + facilities + Copernicus 30m DEM
import json, math, collections, numpy as np
from PIL import Image
UP='/mnt/user-data/uploads/'; DEM='/tmp/r/output_hh.tif'
a=np.array(Image.open(DEM)).astype('float64'); x0,y0,res=76.05,11.62,0.0002777777777777778
H,W=a.shape; dy=res*111320; dx=res*111320*math.cos(math.radians(11.55))
gy,gx=np.gradient(a,dy,dx); slope=np.degrees(np.arctan(np.hypot(gx,gy)))
def filt(arr,r,fn):
    p=np.pad(arr,r,mode='edge'); 
    t=np.stack([p[:,i:i+arr.shape[1]] for i in range(2*r+1)]); t=fn(t,axis=0)
    p=np.pad(t,((r,r),(0,0)),mode='edge'); t=np.stack([p[i:i+arr.shape[0],:] for i in range(2*r+1)]); return fn(t,axis=0)
smax=filt(slope,3,np.max)          # max slope within ~90 m
emax=filt(a,5,np.max)              # highest ground within ~150 m
emin=filt(a,20,np.min)             # lowest ground within ~600 m (drainage proxy)
def px(lon,lat): return min(max(int((y0-lat)/res),0),H-1),min(max(int((lon-x0)/res),0),W-1)
def hav(p,q):
    r=math.pi/180; s=math.sin((q[1]-p[1])*r/2)**2+math.cos(p[1]*r)*math.cos(q[1]*r)*math.sin((q[0]-p[0])*r/2)**2
    return 6371*2*math.atan2(math.sqrt(s),math.sqrt(1-s))
roads=json.load(open(UP+'roads.geojson'))['features']; fac=json.load(open(UP+'facilities.geojson'))['features']
K=lambda c:(round(c[0],6),round(c[1],6))
cnt=collections.Counter(K(c) for f in roads for c in f['geometry']['coordinates'])
junc={k for k,v in cnt.items() if v>1}
for f in roads: cs=f['geometry']['coordinates']; junc.add(K(cs[0])); junc.add(K(cs[-1]))
E=[]
for f in roads:
    cs=[K(c) for c in f['geometry']['coordinates']]; last=0; nm=f['properties'].get('name')
    for i in range(1,len(cs)):
        if cs[i] in junc:
            if cs[last]!=cs[i]: E.append([cs[last],cs[i],sum(hav(cs[j],cs[j+1]) for j in range(last,i)),nm])
            last=i
par={}
def find(x):
    while par.setdefault(x,x)!=x: par[x]=par[par[x]]; x=par[x]
    return x
for u,v,_,_ in E: par[find(u)]=find(v)
big=collections.Counter(find(n) for n in par).most_common(1)[0][0]
E=[e for e in E if find(e[0])==big]
nodes_k=sorted({e[0] for e in E}|{e[1] for e in E}); idx={k:i for i,k in enumerate(nodes_k)}
# facilities
def ftype(p):
    am=p.get('amenity'); return am
facs=[]
for f in fac:
    p=f['properties']; c=f['geometry']['coordinates'][:2]
    facs.append((c[0],c[1],p.get('amenity'),p.get('name') or ''))
w_ex={'school':2,'hospital':3,'clinic':1,'community_centre':2,'place_of_worship':1}
hands=[a[px(*k)]-emin[px(*k)] for k in idx]
HS=float(np.percentile(hands,85))  # 85th-percentile height-above-drainage -> flood index 0
print('HAND pct 10/50/85',np.percentile(hands,[10,50,85]).round(1))
nodes=[]
for k,i in idx.items():
    r,c=px(*k); elev=a[r,c]; hand=elev-emin[r,c]; above=emax[r,c]-elev
    s=float(smax[r,c]); ls=0.6*min(1,max(0,(s-15)/25))+0.4*min(1,max(0,above/60))
    ex=sum(w_ex.get(t,0) for (lo,la,t,n) in facs if hav(k,(lo,la))<0.6)
    nodes.append({'id':i,'lon':k[0],'lat':k[1],'flood':round(100*min(1,max(0,1-hand/HS)),1),'landslide':round(100*ls,1),'slope':round(min(90,s),1),'exposure':round(min(100,15*ex),1)})
edges=[];seen=collections.Counter()
for u,v,km,nm in E:
    a_,b_=idx[u],idx[v]; seen[(a_,b_)]+=1
    edges.append({'id':f'{a_}-{b_}-{seen[(a_,b_)]}','a':a_,'b':b_,'closed':False,'km':round(km,4)})
def nearest(lon,lat):
    best=min(range(len(nodes)),key=lambda i:hav((lon,lat),(nodes[i]['lon'],nodes[i]['lat']))); return best,hav((lon,lat),(nodes[best]['lon'],nodes[best]['lat']))
CAP={'hospital':25,'community_centre':100,'school':150}
shelters=[];used=[]
for lo,la,t,n in facs:
    if t not in CAP: continue
    if any(hav((lo,la),u)<0.15 for u in used if True) and t=='hospital': continue
    nid,d=nearest(lo,la)
    if d>0.4: continue
    used.append((lo,la)); nm=n or f"Unnamed {t.replace('_',' ')}"
    shelters.append({'node':nid,'name':nm,'capacity':CAP[t],'occupied':0,'medical':t=='hospital'})
seen_n=set(); sh=[]
for s in shelters:
    if (s['node'],s['name']) in seen_n: continue
    seen_n.add((s['node'],s['name'])); sh.append(s)
starts=[];
for lo,la,t,n in facs:
    if t in('school','place_of_worship') and n:
        nid,d=nearest(lo,la)
        if d<0.4 and nid not in [x for x,_ in starts]: starts.append((nid,f'Near {n}'))
starts=starts[:24]
for nid,nm in starts: nodes[nid]['name']=nm
out={'nodes':nodes,'edges':edges,'shelters':sh,'starts':[i for i,_ in starts]}
json.dump(out,open('real_data.json','w'),separators=(',',':'))
fl=[n['flood'] for n in nodes];ls_=[n['landslide'] for n in nodes]
print('nodes',len(nodes),'edges',len(edges),'shelters',len(sh),'starts',len(starts))
print('flood pct',np.percentile(fl,[10,50,90]).round(1),'landslide pct',np.percentile(ls_,[10,50,90]).round(1),'slope max',max(n['slope'] for n in nodes))
print('total km',round(sum(e['km'] for e in edges),1),'size KB',round(len(json.dumps(out))/1024))
