const E=require('./dist/engine.js'),assert=require('assert');
// AHP
let r=E.ahp([[1,1,1,1],[1,1,1,1],[1,1,1,1],[1,1,1,1]]);assert(r.weights.every(w=>Math.abs(w-.25)<1e-9)&&r.cr<1e-9);
r=E.ahp([[1,3,5,5],[1/3,1,3,3],[1/5,1/3,1,1],[1/5,1/3,1,1]]);assert(Math.abs(r.weights.reduce((a,b)=>a+b)-1)<1e-9&&r.weights[0]>r.weights[1]&&r.cr<.1);
r=E.ahp([[1,9,1/9,1],[1/9,1,9,1],[9,1/9,1,1],[1,1,1,1]]);assert(r.cr>=.1);
assert.throws(()=>E.ahp([[1,2],[0.5]]));assert.throws(()=>E.ahp([[1,-2],[-.5,1]]));
// ranking + timeline
const d=E.demo(),w=[40,30,15,15];let rk=E.rankShelters(d,35,w,1,20,false);
assert.strictEqual(rk.length,3);assert(!rk[0].reason);assert.strictEqual(rk.find(x=>x.shelter.node===0).reason,'Insufficient space');
rk=E.rankShelters(d,35,w,1,30,true);assert(rk.every(x=>x.reason));assert.strictEqual(rk.find(x=>x.shelter.node===41).reason,'Insufficient space');
rk=E.rankShelters(d,35,w,1,20,true);assert.strictEqual(rk[0].shelter.node,41);assert.strictEqual(rk.find(x=>x.shelter.node===6).reason,'No medical support');
const rt=E.route(d,35,41,w,1,true),tl=E.timeline(d,rt,w,1,{speed:30,cap:40,people:20});
assert(tl.stops.length===rt.path.length&&tl.stops.every((s,i)=>i===0||s.minute>tl.stops[i-1].minute)&&tl.totalMin>tl.loadingMin);
assert(E.timeline(d,rt,w,1,{speed:10,people:20}).totalMin>tl.totalMin);
// layers
let L=E.parseLayer('{"type":"FeatureCollection","features":[{"type":"Feature","properties":{"name":"A"},"geometry":{"type":"Point","coordinates":[76.1,11.8]}},{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[76,11.7],[76.1,11.7],[76.1,11.8],[76,11.7]]]}}]}');assert(L.kind==='geojson'&&L.geoms.length===2);
for(const bad of ['{"type":"Point","coordinates":[200,5]}','{"type":"Point","coordinates":["a",5]}','{"type":"Foo"}','not json','{"type":"FeatureCollection","features":[]}'])assert.throws(()=>E.parseLayer(bad),bad);
L=E.parseLayer('lon,lat,name,flood,slope\n76.09,11.80,"Gauge, A",90,10\n76.1,11.8,B,120,5\nx,1,C,1,1\n');assert(L.kind==='csv'&&L.points.length===1&&L.skipped===2&&L.points[0].name==='Gauge, A');
assert.throws(()=>E.parseLayer('a,b\n1,2'));
const dd=E.demo(),res=E.applyHazards(dd,L.points);assert(res.nodes===1&&res.rows===1);
assert.strictEqual(E.applyHazards(dd,[{lon:10,lat:10,flood:5}]).far,1);
console.log('PASS: AHP, shelter ranking, timeline, layer parsing, hazard merge.');
// UI smoke test with a stubbed DOM (browser validation is still required)
const vm=require('node:vm'),fs=require('node:fs'),els=new Map();
const mk=id=>({id,value:'',checked:false,innerHTML:'',textContent:'',style:{},dataset:{},ins:'',insertAdjacentHTML(p,h){this.ins+=h;},querySelectorAll:()=>[],querySelector(){return mk('x');},showModal(){},close(){},appendChild(){}});
const el=id=>{if(!els.has(id))els.set(id,mk(id));return els.get(id);};
el('people').value='20';el('scenario').value='1';el('layer').value='risk';el('tlspeed').value='30';el('tlcap').value='40';el('tgHeat').checked=true;
el('map').children=[mk('defs'),mk('rect')];
const ctx={Engine:E,document:{getElementById:el,querySelectorAll:()=>[],querySelector:()=>mk('q'),createElement:()=>mk('dlg'),body:mk('body')},setTimeout:()=>{},console,window:{},URL,Blob};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('./dist/app.js','utf8'),ctx);vm.runInContext(fs.readFileSync('./dist/addons.js','utf8'),ctx);
assert(el('ranking').innerHTML.includes('Recommended')&&el('ranking').innerHTML.includes('Insufficient space'));
assert(el('timeline').innerHTML.includes('Recommended route')&&el('timeline').innerHTML.includes('T+'));
assert(el('map').children[1].ins.includes('<rect')&&!el('map').children[1].ins.includes('openstreetmap'));
el('tgTiles').checked=true;el('people').onchange();assert(el('map').children[1].ins.includes('tile.openstreetmap.org'));
el('people').value='30';el('medical').checked=true;el('people').onchange();assert(el('timeline').innerHTML.includes('No route'));assert(!el('ranking').innerHTML.includes('Recommended'));
console.log('PASS: add-on UI smoke test.');
